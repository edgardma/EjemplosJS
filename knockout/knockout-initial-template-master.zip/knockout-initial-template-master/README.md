# knockoutjs-initial-template
Plantilla inicial con Bootstrap4 y KnockoutJS. Initial Template with Bootstrap 4 and KnockoutJS. Modèle initial avec Bootstrap 4 et KnockoutJS
